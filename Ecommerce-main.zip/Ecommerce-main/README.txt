README
	This is our 3rd and final iteration of out Ecommerce application. users are able to post
	a product to sell, buy products, view all the products that are for sale and add
	and finalize purchases through the shopping cart. Purchasing a product will remove
	that product from the product page.
	
	The instructions on using our 3rd iteration of our Ecommerce application is
	staright forward. and same as the 2nd iteration instructions 
	
	To run the program the user must run the ApplicationTester.java file.
	
	
	
	* you should test the main branch for the 3rd iteration not the (new-ecommerce-branch).

Contact
	if you have problems, questions, ideas, or suggestions, please contact us by our university
	emails.
